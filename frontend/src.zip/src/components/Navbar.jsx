import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate  = useNavigate();
  const location  = useLocation();

  const handleLogout = () => { logout(); navigate('/login'); };

  const isActive = (path) => location.pathname === path;
  const isAdmin      = ['admin','superadmin'].includes(user?.role);
  const isSuperAdmin = user?.role === 'superadmin';

  return (
    <nav style={styles.nav}>
      <div style={styles.left}>
        <Link to="/products" style={styles.brand}>
          <span style={styles.brandDot}/>
          Nexora Analytics
        </Link>
        <div style={styles.links}>
          <Link to="/products"  style={isActive('/products')  ? styles.linkActive : styles.link}>Productos</Link>
          {isAdmin && (
            <Link to="/dashboard" style={isActive('/dashboard') ? styles.linkActive : styles.link}>Dashboard</Link>
          )}
          {isAdmin && (
            <Link to="/users" style={isActive('/users') ? styles.linkActive : styles.link}>Usuarios</Link>
          )}
        </div>
      </div>
      <div style={styles.right}>
        {user && (
          <div style={styles.userPill}>
            <div style={styles.avatar}>{user.name?.charAt(0).toUpperCase()}</div>
            <span style={styles.userName}>{user.name}</span>
            <span style={user.role === 'admin' ? styles.roleAdmin : styles.roleCustomer}>
              {user.role}
            </span>
          </div>
        )}
        {user
          ? <button style={styles.logoutBtn} onClick={handleLogout}>Salir</button>
          : <Link to="/login" style={styles.link}>Login</Link>
        }
      </div>
    </nav>
  );
}

const styles = {
  nav:          { display:'flex', justifyContent:'space-between', alignItems:'center', padding:'0 2rem', height:56, background:'#1E1B4B', position:'sticky', top:0, zIndex:100 },
  left:         { display:'flex', alignItems:'center', gap:'2rem' },
  brand:        { display:'flex', alignItems:'center', gap:8, fontWeight:700, fontSize:17, textDecoration:'none', color:'#fff' },
  brandDot:     { width:8, height:8, borderRadius:'50%', background:'#818CF8', display:'inline-block' },
  links:        { display:'flex', gap:4 },
  link:         { textDecoration:'none', color:'#A5B4FC', fontSize:14, padding:'6px 12px', borderRadius:8 },
  linkActive:   { textDecoration:'none', color:'#fff', fontSize:14, padding:'6px 12px', borderRadius:8, background:'rgba(255,255,255,0.1)' },
  right:        { display:'flex', alignItems:'center', gap:12 },
  userPill:     { display:'flex', alignItems:'center', gap:8, background:'rgba(255,255,255,0.08)', padding:'4px 12px 4px 6px', borderRadius:20 },
  avatar:       { width:26, height:26, borderRadius:'50%', background:'#818CF8', color:'#fff', fontSize:12, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center' },
  userName:     { fontSize:13, color:'#E0E7FF', fontWeight:500 },
  roleAdmin:    { fontSize:11, background:'#4F46E5', color:'#fff', padding:'2px 8px', borderRadius:10, fontWeight:500 },
  roleCustomer: { fontSize:11, background:'rgba(255,255,255,0.15)', color:'#C7D2FE', padding:'2px 8px', borderRadius:10 },
  logoutBtn:    { background:'rgba(255,255,255,0.08)', border:'1px solid rgba(255,255,255,0.15)', color:'#A5B4FC', padding:'5px 14px', borderRadius:8, cursor:'pointer', fontSize:13 },
};