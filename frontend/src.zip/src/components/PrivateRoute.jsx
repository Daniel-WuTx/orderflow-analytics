import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const PrivateRoute = ({ children, adminOnly = false }) => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  if (adminOnly && !['admin','superadmin'].includes(user.role))
    return <Navigate to="/products" />;
  return children;
};

export default PrivateRoute;