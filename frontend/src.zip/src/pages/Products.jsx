import { useEffect, useState } from 'react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import ImageCarousel from '../components/ImageCarousel';
import ImageManager from '../components/ImageManager';

const EMPTY = { name:'', description:'', price:'', stock:'', category_id:'' };

export default function Products() {
  const { user }                      = useAuth();
  const isAdmin                       = ['admin','superadmin'].includes(user?.role);
  const [products,      setProducts]  = useState([]);
  const [categories,    setCategories]= useState([]);
  const [search,        setSearch]    = useState('');
  const [loading,       setLoading]   = useState(true);
  const [showModal,     setShowModal] = useState(false);
  const [editing,       setEditing]   = useState(null);
  const [form,          setForm]      = useState(EMPTY);
  const [saving,        setSaving]    = useState(false);
  const [deleting,      setDeleting]  = useState(null);
  const [productImages, setProductImages] = useState({});

  const fetchImages = async (prods) => {
    const entries = await Promise.all(
      prods.map(async p => {
        const { data } = await api.get(`/products/${p.id}/images`);
        return [p.id, data];
      })
    );
    setProductImages(Object.fromEntries(entries));
  };

  const fetchProducts = async (q = '') => {
    setLoading(true);
    try {
      const { data } = await api.get(`/products?search=${q}`);
      setProducts(data.products);
      await fetchImages(data.products);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
    api.get('/products/categories').then(r => setCategories(r.data));
  }, []);

  const openCreate = () => {
    setEditing(null);
    setForm(EMPTY);
    setShowModal(true);
  };

  const openEdit = (p) => {
    setEditing(p);
    setForm({
      name: p.name,
      description: p.description || '',
      price: p.price,
      stock: p.stock,
      category_id: p.category_id || ''
    });
    setShowModal(true);
  };

  const handleSubmit = async () => {
    if (!form.name || !form.price) return alert('Nombre y precio son requeridos');
    setSaving(true);
    try {
      if (editing) {
        const { data } = await api.put(`/products/${editing.id}`, form);
        setProducts(prev => prev.map(p => p.id === editing.id ? { ...p, ...data } : p));
      } else {
        await api.post('/products', form);
        await fetchProducts();
      }
      setShowModal(false);
    } catch (err) {
      alert(err.response?.data?.error || 'Error al guardar');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('¿Eliminar este producto?')) return;
    setDeleting(id);
    try {
      await api.delete(`/products/${id}`);
      setProducts(prev => prev.filter(p => p.id !== id));
    } catch (err) {
      alert(err.response?.data?.error || 'Error al eliminar');
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div style={{background:'#F8F9FB', minHeight:'100vh'}}>

      {/* Header */}
      <div style={{background:'#fff', borderBottom:'1px solid #F0F0F0', padding:'1.25rem 2rem', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <div>
          <h1 style={{fontSize:20, fontWeight:700, color:'#111827', margin:0}}>Productos</h1>
          <p style={{fontSize:13, color:'#6B7280', margin:'2px 0 0'}}>{products.length} productos disponibles</p>
        </div>
        {isAdmin && (
          <button onClick={openCreate} style={styles.btnPrimary}>
            + Nuevo producto
          </button>
        )}
      </div>

      <div style={{padding:'1.5rem 2rem', maxWidth:1400, margin:'0 auto'}}>

        {/* Buscador */}
        <input
          style={styles.search}
          placeholder="Buscar producto..."
          value={search}
          onChange={e => { setSearch(e.target.value); fetchProducts(e.target.value); }}
        />

        {/* Grid */}
        {loading ? (
          <p style={{color:'#6B7280', marginTop:'2rem'}}>Cargando...</p>
        ) : (
          <div style={styles.grid}>
            {products.map(p => (
              <div key={p.id} style={styles.card}>
                <ImageCarousel
                  images={productImages[p.id] || []}
                  productName={p.name}
                />
                <div style={styles.cardTop}>
                  <span style={styles.categoryBadge}>{p.category_name || 'Sin categoría'}</span>
                  {p.stock === 0 && <span style={styles.outStock}>Agotado</span>}
                </div>
                <p style={styles.productName}>{p.name}</p>
                <p style={styles.productDesc}>{p.description}</p>
                <div style={styles.cardFooter}>
                  <span style={styles.price}>${Number(p.price).toFixed(2)}</span>
                  <span style={p.stock > 0 ? styles.inStock : styles.outStockBadge}>
                    {p.stock > 0 ? `${p.stock} en stock` : 'Agotado'}
                  </span>
                </div>
                {isAdmin && (
                  <>
                    <ImageManager
                      productId={p.id}
                      images={productImages[p.id] || []}
                      onUpdate={async () => {
                        const { data } = await api.get(`/products/${p.id}/images`);
                        setProductImages(prev => ({ ...prev, [p.id]: data }));
                      }}
                    />
                    <div style={styles.cardActions}>
                      <button onClick={() => openEdit(p)} style={styles.btnEdit}>Editar</button>
                      <button
                        onClick={() => handleDelete(p.id)}
                        disabled={deleting === p.id}
                        style={styles.btnDelete}
                      >
                        {deleting === p.id ? '...' : 'Eliminar'}
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div style={styles.overlay}>
          <div style={styles.modal}>
            <div style={styles.modalHeader}>
              <h2 style={styles.modalTitle}>{editing ? 'Editar producto' : 'Nuevo producto'}</h2>
              <button onClick={() => setShowModal(false)} style={styles.closeBtn}>✕</button>
            </div>

            <div style={styles.formGrid}>
              <div style={styles.field}>
                <label style={styles.label}>Nombre *</label>
                <input style={styles.input} value={form.name}
                  onChange={e => setForm({...form, name: e.target.value})}
                  placeholder="Nombre del producto"/>
              </div>
              <div style={styles.field}>
                <label style={styles.label}>Categoría</label>
                <select style={styles.input} value={form.category_id}
                  onChange={e => setForm({...form, category_id: e.target.value})}>
                  <option value="">Sin categoría</option>
                  {categories.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div style={styles.field}>
                <label style={styles.label}>Precio *</label>
                <input style={styles.input} type="number" min="0" step="0.01"
                  value={form.price}
                  onChange={e => setForm({...form, price: e.target.value})}
                  placeholder="0.00"/>
              </div>
              <div style={styles.field}>
                <label style={styles.label}>Stock</label>
                <input style={styles.input} type="number" min="0"
                  value={form.stock}
                  onChange={e => setForm({...form, stock: e.target.value})}
                  placeholder="0"/>
              </div>
              <div style={{...styles.field, gridColumn:'1 / -1'}}>
                <label style={styles.label}>Descripción</label>
                <textarea style={{...styles.input, height:80, resize:'vertical'}}
                  value={form.description}
                  onChange={e => setForm({...form, description: e.target.value})}
                  placeholder="Descripción del producto"/>
              </div>
            </div>

            <div style={styles.modalFooter}>
              <button onClick={() => setShowModal(false)} style={styles.btnCancel}>Cancelar</button>
              <button onClick={handleSubmit} disabled={saving} style={styles.btnPrimary}>
                {saving ? 'Guardando...' : editing ? 'Guardar cambios' : 'Crear producto'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  search:        { width:'100%', padding:'10px 16px', borderRadius:10, border:'1px solid #E5E7EB', fontSize:14, marginBottom:'1.5rem', background:'#fff' },
  grid:          { display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(260px,1fr))', gap:16 },
  card:          { background:'#fff', border:'1px solid #F0F0F0', borderRadius:12, padding:'1.25rem', display:'flex', flexDirection:'column', gap:8 },
  cardTop:       { display:'flex', justifyContent:'space-between', alignItems:'center' },
  categoryBadge: { fontSize:11, background:'#EDE9FE', color:'#4C1D95', padding:'3px 8px', borderRadius:20, fontWeight:500 },
  productName:   { fontSize:15, fontWeight:600, color:'#111827', margin:0 },
  productDesc:   { fontSize:13, color:'#6B7280', lineHeight:1.5, flex:1 },
  cardFooter:    { display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:4 },
  price:         { fontSize:17, fontWeight:700, color:'#4F46E5' },
  inStock:       { fontSize:11, background:'#ECFDF5', color:'#065F46', padding:'3px 8px', borderRadius:20 },
  outStockBadge: { fontSize:11, background:'#FEF2F2', color:'#991B1B', padding:'3px 8px', borderRadius:20 },
  outStock:      { fontSize:11, background:'#FEF2F2', color:'#991B1B', padding:'3px 8px', borderRadius:20 },
  cardActions:   { display:'flex', gap:8, marginTop:4, paddingTop:10, borderTop:'1px solid #F3F4F6' },
  btnEdit:       { flex:1, padding:'6px', borderRadius:8, border:'1px solid #E5E7EB', background:'#fff', color:'#374151', fontSize:13, cursor:'pointer', fontWeight:500 },
  btnDelete:     { flex:1, padding:'6px', borderRadius:8, border:'1px solid #FECACA', background:'#FEF2F2', color:'#991B1B', fontSize:13, cursor:'pointer', fontWeight:500 },
  btnPrimary:    { padding:'9px 18px', borderRadius:8, background:'#4F46E5', color:'#fff', border:'none', fontSize:14, cursor:'pointer', fontWeight:500 },
  overlay:       { position:'fixed', inset:0, background:'rgba(0,0,0,0.4)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:200 },
  modal:         { background:'#fff', borderRadius:16, padding:'1.5rem', width:'100%', maxWidth:520, margin:'0 1rem' },
  modalHeader:   { display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'1.25rem' },
  modalTitle:    { fontSize:17, fontWeight:700, color:'#111827', margin:0 },
  closeBtn:      { background:'none', border:'none', fontSize:18, cursor:'pointer', color:'#9CA3AF', padding:4 },
  formGrid:      { display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 },
  field:         { display:'flex', flexDirection:'column', gap:6 },
  label:         { fontSize:13, fontWeight:500, color:'#374151' },
  input:         { padding:'9px 12px', borderRadius:8, border:'1px solid #E5E7EB', fontSize:14, background:'#fff', color:'#111827', width:'100%' },
  modalFooter:   { display:'flex', justifyContent:'flex-end', gap:10, marginTop:'1.5rem', paddingTop:'1rem', borderTop:'1px solid #F3F4F6' },
  btnCancel:     { padding:'9px 18px', borderRadius:8, border:'1px solid #E5E7EB', background:'#fff', color:'#374151', fontSize:14, cursor:'pointer' },
};