import { useEffect, useState } from 'react';
import {
  AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell
} from 'recharts';
import api from '../api/axios';

const COLORS = ['#4F46E5','#10B981','#F59E0B','#EF4444','#8B5CF6'];

const segStyle = {
  VIP:        { background:'#EDE9FE', color:'#4C1D95' },
  Leal:       { background:'#ECFDF5', color:'#065F46' },
  Prometedor: { background:'#FEF3C7', color:'#92400E' },
  'En riesgo':{ background:'#FEF2F2', color:'#991B1B' },
};

const MetricCard = ({ label, value, change, changeUp, color }) => (
  <div style={{background:'#fff',border:'1px solid #F0F0F0',borderRadius:12,padding:'1.1rem 1.25rem'}}>
    <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:6}}>
      <span style={{width:6,height:6,borderRadius:'50%',background:color,display:'inline-block'}}/>
      <span style={{fontSize:12,color:'#6B7280'}}>{label}</span>
    </div>
    <div style={{fontSize:26,fontWeight:700,color:'#111827',lineHeight:1}}>{value}</div>
    {change && (
      <div style={{fontSize:12,marginTop:6,color: changeUp ? '#059669' : '#DC2626'}}>
        {change}
      </div>
    )}
  </div>
);

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{background:'#fff',border:'1px solid #E5E7EB',borderRadius:8,padding:'8px 12px',fontSize:13}}>
      <p style={{color:'#6B7280',marginBottom:4}}>{label}</p>
      {payload.map((p,i) => (
        <p key={i} style={{color:p.color,fontWeight:500}}>{p.name}: {p.name === 'Ingresos' ? `$${Number(p.value).toFixed(2)}` : p.value}</p>
      ))}
    </div>
  );
};

export default function Dashboard() {
  const [summary,  setSummary]  = useState(null);
  const [sales,    setSales]    = useState([]);
  const [topProds, setTopProds] = useState([]);
  const [rfm,      setRfm]      = useState([]);
  const [loading,  setLoading]  = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/analytics/summary'),
      api.get('/analytics/sales-by-month'),
      api.get('/analytics/top-products'),
      api.get('/analytics/rfm'),
    ]).then(([s, sl, tp, r]) => {
      setSummary(s.data);
      setSales(sl.data.map(d => ({ ...d, revenue: parseFloat(d.revenue), total_orders: parseInt(d.total_orders) })));
      setTopProds(tp.data.map(d => ({ ...d, units_sold: parseInt(d.units_sold) })));
      setRfm(r.data);
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:'60vh'}}>
      <p style={{color:'#6B7280',fontSize:15}}>Cargando analytics...</p>
    </div>
  );

  const rfmCount = rfm.reduce((acc, c) => {
    acc[c.segment] = (acc[c.segment] || 0) + 1;
    return acc;
  }, {});

  const rfmDonut = Object.entries(rfmCount).map(([name, value]) => ({ name, value }));

  return (
    <div style={{background:'#F8F9FB',minHeight:'100vh'}}>

      {/* Header */}
      <div style={{background:'#fff',borderBottom:'1px solid #F0F0F0',padding:'1.25rem 2rem',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <div>
          <h1 style={{fontSize:20,fontWeight:700,color:'#111827',margin:0}}>Panel de analytics</h1>
          <p style={{fontSize:13,color:'#6B7280',margin:'2px 0 0'}}>Resumen del negocio en tiempo real</p>
        </div>
        <span style={{background:'#ECFDF5',color:'#065F46',fontSize:12,padding:'4px 12px',borderRadius:20,fontWeight:500}}>
          En vivo
        </span>
      </div>

      <div style={{padding:'1.5rem 2rem',maxWidth:1400,margin:'0 auto'}}>

        {/* Métricas */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',gap:14,marginBottom:20}}>
          <MetricCard label="Ingresos totales"  value={`$${Number(summary.total_revenue).toLocaleString('es-CO',{minimumFractionDigits:2})}`} change="+12.4% este mes" changeUp color="#4F46E5"/>
          <MetricCard label="Órdenes totales"   value={summary.total_orders}    change="+8 esta semana" changeUp color="#10B981"/>
          <MetricCard label="Clientes"           value={summary.total_customers} change="+3 nuevos"      changeUp color="#F59E0B"/>
          <MetricCard label="Productos activos"  value={summary.active_products} change="Stock disponible"       color="#EF4444"/>
        </div>

        {/* Gráfica de ventas + Donut RFM */}
        <div style={{display:'grid',gridTemplateColumns:'2fr 1fr',gap:14,marginBottom:20}}>

          <div style={{background:'#fff',border:'1px solid #F0F0F0',borderRadius:12,padding:'1.25rem'}}>
            <p style={{fontSize:14,fontWeight:600,color:'#111827',margin:'0 0 2px'}}>Ventas por mes</p>
            <p style={{fontSize:12,color:'#9CA3AF',margin:'0 0 1rem'}}>Ingresos de los últimos 12 meses</p>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={sales}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#4F46E5" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#4F46E5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" vertical={false}/>
                <XAxis dataKey="month" tick={{fontSize:11,fill:'#9CA3AF'}} axisLine={false} tickLine={false}/>
                <YAxis tick={{fontSize:11,fill:'#9CA3AF'}} axisLine={false} tickLine={false} tickFormatter={v => `$${v}`}/>
                <Tooltip content={<CustomTooltip/>}/>
                <Area type="monotone" dataKey="revenue" name="Ingresos" stroke="#4F46E5" strokeWidth={2} fill="url(#colorRevenue)"/>
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div style={{background:'#fff',border:'1px solid #F0F0F0',borderRadius:12,padding:'1.25rem'}}>
            <p style={{fontSize:14,fontWeight:600,color:'#111827',margin:'0 0 2px'}}>Segmentos RFM</p>
            <p style={{fontSize:12,color:'#9CA3AF',margin:'0 0 1rem'}}>Distribución de clientes</p>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={rfmDonut} layout="vertical" barSize={18}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" horizontal={false}/>
                <XAxis type="number" tick={{fontSize:11,fill:'#9CA3AF'}} axisLine={false} tickLine={false}/>
                <YAxis dataKey="name" type="category" tick={{fontSize:11,fill:'#6B7280'}} axisLine={false} tickLine={false} width={80}/>
                <Tooltip/>
                <Bar dataKey="value" name="Clientes" radius={[0,6,6,0]}>
                  {rfmDonut.map((_, i) => <Cell key={i} fill={COLORS[i]}/>)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top productos + Tabla RFM */}
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>

          <div style={{background:'#fff',border:'1px solid #F0F0F0',borderRadius:12,padding:'1.25rem'}}>
            <p style={{fontSize:14,fontWeight:600,color:'#111827',margin:'0 0 2px'}}>Top productos</p>
            <p style={{fontSize:12,color:'#9CA3AF',margin:'0 0 1rem'}}>Por unidades vendidas</p>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={topProds} layout="vertical" barSize={16}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" horizontal={false}/>
                <XAxis type="number" tick={{fontSize:11,fill:'#9CA3AF'}} axisLine={false} tickLine={false}/>
                <YAxis dataKey="name" type="category" tick={{fontSize:11,fill:'#6B7280'}} axisLine={false} tickLine={false} width={120}/>
                <Tooltip/>
                <Bar dataKey="units_sold" name="Unidades" fill="#4F46E5" radius={[0,6,6,0]}>
                  {topProds.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]}/>)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div style={{background:'#fff',border:'1px solid #F0F0F0',borderRadius:12,padding:'1.25rem'}}>
            <p style={{fontSize:14,fontWeight:600,color:'#111827',margin:'0 0 2px'}}>Clientes destacados</p>
            <p style={{fontSize:12,color:'#9CA3AF',margin:'0 0 1rem'}}>Por valor total gastado</p>
            <table style={{width:'100%',borderCollapse:'collapse'}}>
              <thead>
                <tr>
                  {['Cliente','Gastado','Órdenes','Segmento'].map(h => (
                    <th key={h} style={{fontSize:11,color:'#9CA3AF',textAlign:'left',padding:'0 8px 8px',fontWeight:500,textTransform:'uppercase',letterSpacing:'.04em'}}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rfm.slice(0,6).map(c => (
                  <tr key={c.id}>
                    <td style={{fontSize:13,color:'#374151',padding:'8px',borderTop:'1px solid #F9FAFB'}}>{c.name}</td>
                    <td style={{fontSize:13,color:'#374151',padding:'8px',borderTop:'1px solid #F9FAFB',fontWeight:500}}>${Number(c.monetary).toFixed(0)}</td>
                    <td style={{fontSize:13,color:'#374151',padding:'8px',borderTop:'1px solid #F9FAFB'}}>{c.frequency}</td>
                    <td style={{padding:'8px',borderTop:'1px solid #F9FAFB'}}>
                      <span style={{fontSize:11,padding:'3px 8px',borderRadius:20,fontWeight:500,...(segStyle[c.segment]||{})}}>
                        {c.segment}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>
  );
}